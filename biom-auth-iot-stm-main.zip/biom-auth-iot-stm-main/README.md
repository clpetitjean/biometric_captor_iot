# biom-auth-iot-stm

This repo hold the code for MbedOS